# DeepWork Debug Skills Bundle

Generated: 2026-06-22

This bundle contains DeepWork diagnosis skills for investigating stuck secure workspace, VM readiness, bridge, image-policy, and Windows log issues on another machine.

## Packaged macOS App Compatibility

The first-line diagnosis flow is compatible with an installed packaged macOS app. The skills read:

- `~/.deepwork/logs/app.jsonl`
- `~/.deepwork/audit.jsonl`
- `~/Library/Application Support/deepwork/secure-vm/**/manifest.json`
- legacy app-support paths `Deepwork` and `DeepWork`

For direct bridge smoke, the macOS skill first uses a repo/dev helper path and then falls back to the packaged app helper:

```bash
/Applications/DeepWork.app/Contents/Resources/app.asar.unpacked/out/resources/macos-secure-vm-helper/SecureVMBootSmokeHelper
```

## Included Skills

- `deepwork-vm-debug-triage`: macOS Deep Work secure VM readiness, image, bridge, guest daemon, and runtime cache triage.
- `deepwork-windows-log-diagnosis`: Windows DeepWork log, audit, prerequisite, and secure workspace availability diagnosis.
- `test-deepwork-dev-chat`: local dev app UI smoke test flow for Work chat.
- `deepwork-vm-image-policy-bump`: maintainer-oriented checklist for image-policy/version mismatch remediation. Use this only after diagnosis shows an image policy/version problem.

`deepwork-vm-release-smoke` is intentionally not included because it is a release/build workflow, not a first-line teammate diagnosis workflow.

## Install For Codex

Unzip this archive, then copy the skill directories:

```bash
mkdir -p ~/.codex/skills
cp -R skills/deepwork-vm-debug-triage ~/.codex/skills/
cp -R skills/deepwork-windows-log-diagnosis ~/.codex/skills/
cp -R skills/test-deepwork-dev-chat ~/.codex/skills/
cp -R skills/deepwork-vm-image-policy-bump ~/.codex/skills/
```

Restart Codex after copying.

## Install For Claude / Project Agents

If using project-local skills, unzip from the repository root and copy:

```bash
mkdir -p .agents/skills
cp -R skills/deepwork-vm-debug-triage .agents/skills/
cp -R skills/deepwork-windows-log-diagnosis .agents/skills/
cp -R skills/test-deepwork-dev-chat .agents/skills/
cp -R skills/deepwork-vm-image-policy-bump .agents/skills/
```

For a user-level Claude setup, copy the same directories into the configured Claude skills directory used on that machine.

## Suggested First Prompt

```text
DeepWork 앱이 "보안 작업 공간을 시작하는 중" 또는 "에이전트가 동작 중입니다" 화면에서 오래 멈춥니다.
deepwork-vm-debug-triage 스킬을 사용해서 ~/.deepwork/logs/app.jsonl, ~/.deepwork/audit.jsonl,
설치된 secure-vm manifest를 근거로 image preparation, VM boot, guest bridge, runtime cache 중 어디서 막혔는지 분류해줘.
```

For Windows:

```text
deepwork-windows-log-diagnosis 스킬을 사용해서 Windows DeepWork secure workspace가 ready/preparing/unavailable 중 어디인지
~/.deepwork 로그와 audit metadata 기준으로 진단해줘.
```

## First Evidence To Collect

macOS:

```bash
tail -n 700 ~/.deepwork/logs/app.jsonl \
  | rg 'DeepWorkVM|AgentTimeline|PERF|Runtime|MCPClient|deepworkd|bridge'

jq -c 'select(.type|test("vm_session|shell_command")) | {t:.timestamp,type,decision,metadata:.metadata}' \
  ~/.deepwork/audit.jsonl
```

Windows PowerShell:

```powershell
Select-String -Path "$HOME\.deepwork\logs\app.jsonl" `
  -Pattern "DeepWorkVM|deep-work|Deep Work|Hyper-V|windows-hyperv|secure execution|unavailable|executionIsolation|executionProfile|secureWorkspace" |
  Select-Object -Last 120 |
  ForEach-Object { $_.Line }
```
