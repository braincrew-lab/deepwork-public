---
name: deepwork-vm-image-policy-bump
description: Update DeepWork VM image policy versions and release tags safely in deep-agent-builder-desktop. Use when image contents, deepworkd provisioning, install-policy.json, accepted VM versions, release URLs, dev cache paths, or stale install reuse behavior change; especially when avoiding reuse of an old verified 20GB VM image under deepwork, Deepwork, or DeepWork app support paths.
---

# DeepWork VM Image Policy Bump

## Overview

Use this when a VM image changes in a way that should force local installs to replace the previous verified image. The main invariant: if the image bytes or guest provisioning changed, the active image version must change too.

## Version Bump Rule

Do not rebuild different image bytes under the same active policy version unless the user explicitly wants a local-only one-off. The app may reuse an existing verified install if its manifest version is still accepted, even when a newer release asset exists.

Prefer:

- new image version, for example `ubuntu-22.04.5-deepworkd-0.1.1`
- new release tag, for example `deep-work-vm-2026-06-05-deepworkd-smoke-macos-arm64-v2`
- updated app default policy URL and dev cache path
- tests proving stale installs outside active policy are skipped or replaced

## Files To Inspect

Use `rg` before editing:

```bash
rg -n 'ubuntu-22\.04\.5-deepworkd|deepworkd-smoke|DEFAULT_MACOS_ARM64_VM_POLICY|SUPPORTED_IMAGE_VERSIONS|VERIFIED_IMAGE_VERSIONS' \
  src scripts tests docs .github
```

Common files:

- `.github/workflows/deep-work-vm-image.yml`
- `scripts/deep-work-vm/expanded-image-artifact.cjs`
- `scripts/deep-work-vm/install-policy.cjs`
- `src/main/agent/execution/deep-work-vm-app-prerequisites.ts`
- `src/main/agent/execution/deep-work-vm-image-installer.ts`
- `src/main/agent/execution/deep-work-vm-availability-probe.ts`
- `tests/main/execution-environment.test.cjs`
- `tests/scripts/deep-work-vm-*.test.cjs`
- `docs/deep-work-vm-debugging.md`
- `docs/issues/deep-work-vm-base-image-artifact.md`

## Patch Checklist

Update these as one coherent unit:

- image builder version constant for the changed profile
- workflow `IMAGE_VERSION` for the profile
- install-policy supported image versions
- app default macOS policy URL
- app default macOS policy version
- dev release tag
- dev cache version directory
- availability probe verified versions
- image installer supported versions
- tests that construct expanded image policies
- docs/examples that show active image version or release URL

If the office/toolchain profile did not change, do not bump its version just because the smoke image changed. Keep the profile versions independent.

## Stale Install And Casing Guard

The product may encounter these App Support names:

```text
~/Library/Application Support/deepwork
~/Library/Application Support/Deepwork
~/Library/Application Support/DeepWork
```

Do not normalize all product text casing as a broad fix. The real risk is duplicate 20GB images across those paths. The app should:

- install new images into the current Electron `userData` path
- probe legacy paths only to avoid needless redownloads
- skip or replace verified installs whose manifest version is outside the active app policy
- report conflicting duplicates rather than silently deleting user data

## Image Provisioning Changes

For `deepworkd.service`, remember the guest service runs as:

```ini
User=ubuntu
Group=ubuntu
SupplementaryGroups=tty
```

If the cloud image may not contain that account, the image build must provision it before enabling the service:

```bash
getent group ubuntu >/dev/null 2>&1 || groupadd ubuntu
id -u ubuntu >/dev/null 2>&1 || useradd --create-home --shell /bin/bash --gid ubuntu ubuntu
install -d -o ubuntu -g ubuntu -m 0755 /home/ubuntu
```

Add this to both smoke and office/toolchain image builders if both inject the same `deepworkd.service`.

## Verification

Run the targeted tests for version and policy changes:

```bash
node --test tests/scripts/deep-work-vm-expanded-image-artifact.test.cjs \
  tests/scripts/deep-work-vm-office-toolchain-image-artifact.test.cjs \
  tests/scripts/deep-work-vm-install-policy.test.cjs \
  tests/scripts/deep-work-vm-image-workflow.test.cjs \
  tests/main/execution-environment.test.cjs
```

Then run broader checks before committing:

```bash
pnpm typecheck
pnpm lint
pnpm format:check
git diff --check
```

## Release Follow-Through

After committing and pushing, use `$deepwork-vm-release-smoke` to create the release image, download assets, and prove the local app replaces stale installs before testing `uname`.
