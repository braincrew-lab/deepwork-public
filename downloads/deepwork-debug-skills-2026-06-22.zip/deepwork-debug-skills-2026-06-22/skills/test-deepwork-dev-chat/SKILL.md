---
name: test-deepwork-dev-chat
description: Run and manually smoke-test the DeepWork/deep-agent-builder-desktop Electron dev app by starting pnpm dev, selecting the correct Work-mode window, sending a chat message, and verifying the response. Use when the user asks Codex to "pnpm dev", open the app, test Work chat, send a message in Work mode, or repeat the desktop chat-send verification flow in this repository.
---

# Test DeepWork Dev Chat

## Overview

Use this workflow to verify the local DeepWork desktop app end to end from the real UI: start the dev server, target the correct Electron instance, send a Work-mode chat message, and confirm the response. The fragile parts are Electron instance selection and stale accessibility indexes after changing screens.

## Workflow

### 1. Start Or Locate Dev

Use the repo root unless the user provides another workspace:

```bash
cd /Users/neulhan-b/Braincrew/deep-agent-builder-desktop
pnpm dev
```

Run `pnpm dev` in a PTY session so it can keep running. If the command appears to exit after `starting electron app...`, do not assume failure; inspect processes:

```bash
ps -axo pid,ppid,command | rg -i 'electron-vite|vite|deep-agent-builder-desktop|Electron.app/Contents/MacOS/Electron'
```

Record the renderer URL printed by Vite. Port conflicts are normal; the already-open app may still point at `localhost:5173` while a new attempt tries `5174`.

### 2. Target The Right Electron App

Use Computer Use for UI operation. Before interacting in each assistant turn, call `get_app_state`.

Do not target the generic app name `Electron` when more than one Electron app is running. Use the full app path for this repo:

```text
/Users/neulhan-b/Braincrew/deep-agent-builder-desktop/node_modules/electron/dist/Electron.app
```

Verify all of these before typing:

- Window title is `deepwork`.
- The HTML URL is localhost, not Electron's default `default_app.asar` page.
- The Work radio button is selected, or click `Work` to select it.
- The visible workspace/app is from `/deep-agent-builder-desktop`, not another worktree such as `deep-agent-builder-desktop-login-pr`.

### 3. Send A Work Chat

Prefer a new thread unless the user asks to reuse the current one:

1. Click `새 스레드`.
2. Immediately call `get_app_state` again. Accessibility element indexes often change after the new-thread transition.
3. Find the current `텍스트 엔트리 영역` with placeholder `메시지...`.
4. Set its value to the user's requested prompt, or use this harmless smoke-test prompt:

```text
테스트 메시지입니다. 한 문장으로 짧게 답해주세요.
```

5. Confirm the `메시지 보내기` button is enabled.
6. Click `메시지 보내기`.
7. Call `get_app_state` again after a short wait.

If a click does not seem to take, refresh the app state before retrying. Avoid repeated blind clicks.

### 4. Verify And Report

Successful verification means:

- The sent user message appears in the thread.
- An assistant response appears.
- The completion status appears, for example `5.1s 만에 응답 완료`.
- The input is cleared and the send button is disabled again.

Report the exact prompt sent, whether a response arrived, and any important side-panel status. If the Deep Work secure workspace panel says VM/backend/image verification is unavailable but normal chat works, say that clearly; it is not a blocker for plain Work chat.

Leave the dev process running unless the user asked for a one-off check or cleanup.
