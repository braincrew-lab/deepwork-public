---
name: deepwork-vm-debug-triage
description: DeepWork secure VM readiness and bridge failure triage for deep-agent-builder-desktop, including direct guest disk log inspection and virtio JSONL bridge smoke. Use when the app says "보안 실행 작업 공간이 아직 준비 중입니다", uname/tool execution fails, the Deep Work security panel is stuck on 준비 중, logs mention DeepWorkVM, AgentTimeline, bridge_spawn, bridge_process_close, deepworkd, coworkd, guest-login, vm_session_failure, image-policy, runtimeReadinessProof, hdiutil/debugfs/e2fsprogs, qemu, or guest syslog.
---

# DeepWork VM Debug Triage

## Overview

Use this to classify DeepWork VM failures before patching. The goal is to decide whether the blocker is LLM latency, image preparation, VM boot, guest daemon bridge readiness, runtime cache, or stale install policy.

## Collect Evidence

Start with logs and current VM/Electron processes:

```bash
tail -n 700 ~/.deepwork/logs/app.jsonl \
  | rg 'DeepWorkVM|AgentTimeline|PERF|Runtime|MCPClient|deepworkd|bridge'

jq -c 'select(.type|test("vm_session|shell_command")) | {t:.timestamp,type,decision,metadata:.metadata}' \
  ~/.deepwork/audit.jsonl

ps -axo pid,ppid,etime,command \
  | rg -i 'SecureVMBootSmokeHelper|deep-agent-builder-desktop/node_modules/electron|pnpm dev|electron-vite dev'
```

Inspect installed manifests in primary and legacy app support locations:

```bash
for dir in \
  "$HOME/Library/Application Support/deepwork" \
  "$HOME/Library/Application Support/Deepwork" \
  "$HOME/Library/Application Support/DeepWork"
do
  find "$dir/secure-vm" -maxdepth 4 -name manifest.json -print 2>/dev/null
done
```

For each manifest:

```bash
jq '{version,imageId,toolchainProfile,buildMode,runtime:.runtime,install:.install.files}' \
  "/path/to/manifest.json"
```

## Classify The Failure

### LLM Or Tool Loop Latency

Look at `[PERF:*][invoke-end]`:

- `first_chunk` under a few hundred ms means the UI spinner delay is not initial runtime creation.
- `shell` near `0-10ms` means command execution failed closed immediately.
- `shell` near the configured command-readiness preflight timeout means the
  command waited for bridge readiness and then failed closed. Historically this
  was 1500ms; current macOS deepworkd cold boot should use the helper boot
  timeout plus a small grace window.
- Large `llm_etc` means model/tool loop time, not VM boot.

### Image Preparation Or Stale Install

Look for:

- `[DeepWorkVM][install_skip]`
- `[DeepWorkVM][dev_policy_skip]`
- `image-policy`
- `policy version is outside the active app policy`
- `verified install version is outside the active app policy`

If the image content changed, do not reuse the same image version. Use `$deepwork-vm-image-policy-bump`.

The app should install into the current Electron `userData` path, usually:

```text
~/Library/Application Support/deepwork
```

Legacy `Deepwork` and `DeepWork` paths may be probed to avoid duplicate 20GB downloads, but a new install should not rewrite casing or create parallel active images.

### VM Boot

`[DeepWorkVM][vm_session_start]` followed by `[vm_session_ready]` means the host backend created a VM session object. It does not prove live guest daemon readiness unless `runtimeReadinessProof.live` is available.

If `[DeepWorkVM][vm_session_failure]` says disk-space, entitlement, helper missing, or image hash mismatch, fix that category first.

### Guest Bridge

For macOS deepworkd images, the expected contract is:

- runtime identity: `deepworkd-compatible`
- named virtio port: `deepwork.bridge`
- guest device: `/dev/virtio-ports/deepwork.bridge`
- service: `deepworkd.service`

Interpret bridge stages:

- `guest-login`: VM reached login prompt, but the guest daemon did not produce bridge output.
- `deepworkd-port-wait` or `deepworkd-port-missing`: service started, but the named virtio port was not visible in the guest.
- `deepworkd-tty-wait` or `deepworkd-tty-missing`: stale image still depends on ordinal `/dev/hvc1`.
- `deepworkd-starting`: service reached daemon launch; inspect JSONL protocol and manifest mismatch.
- `coworkd-*`: stale legacy runtime.

If a fresh `deepworkd-compatible` image reaches `guest-login` and never prints `deepworkd.service waiting for bridge port` to `/dev/hvc0`, inspect image provisioning before adding host-side readiness guards. The systemd unit runs as `User=ubuntu`/`Group=ubuntu`; the image build must create that group, user, and `/home/ubuntu`.

If guest syslog shows `status=226/NAMESPACE` or `Failed to set up mount namespacing`, inspect the systemd unit hardening before touching host readiness. A known failure is combining `PrivateTmp=true` with a volatile `ReadWritePaths=/tmp/deep-work`: systemd can fail before `ExecStartPre` because `/tmp/deep-work` does not exist inside the unit namespace. Prefer durable write paths such as `/workspaces`; if `/tmp` is needed, create it through a systemd-supported tmpfiles or runtime directory mechanism rather than adding another host-side guard.

If helper logs stop at `deepworkd-preflight-complete`, do not conclude the bridge is dead until you send JSONL on stdin. `SecureVMBootSmokeHelper --deepworkd-bridge` forwards stdin to the guest and streams guest JSONL back; it does not initiate `hello`/`ready` by itself.

If the app reports “workspace preparing” quickly but direct helper smoke reaches
`deepworkd-preflight-complete` and then returns `hello_ok`, `ready_ok`, and
`exitCode:0` after JSONL input, classify it as a host readiness lifecycle bug,
not an image or guest daemon bug. Inspect the macOS backend command preflight
budget and whether background `startBridgeReady()` success is promoted to a
`live-ready-ok` runtime proof.

If the app reaches `deepworkd-preflight-complete` and then fails with
`Deep Work guest daemon image identity does not match the image manifest`,
inspect the `hello_ok.guest.imageId` value against the installed manifest
`imageId`. A legacy deepworkd image can report the generic fallback
`deep-work-ubuntu-jammy` because `DEEP_WORK_IMAGE_ID` was not present in the
guest service environment, while the manifest expects a build-specific id such
as `deep-work-ubuntu-jammy-deepworkd-macos-arm64`. Treat a generic guest id plus
matching runtime name, service name, protocol, and ready checks as an app-side
live proof compatibility issue; treat any other specific image id mismatch as
an image-policy failure. Future images should provision `/etc/deepwork/image.env`
and load it from `deepworkd.service` with `EnvironmentFile=-/etc/deepwork/image.env`.

### Runtime Cache

If a failed background bridge session remains cached, new commands can fail quickly with “workspace preparing”. Look for `vm_session_cleanup` after failures. If cleanup is missing, inspect lifecycle cache behavior before changing the guest image.

## Direct Guest Disk Log Inspection

Use this when the VM boots to `guest-login`, helper diagnostics are inconclusive, or the service output never appears on the boot console.

Prefer the Apple Silicon Homebrew prefix:

```bash
BREW=/opt/homebrew/bin/brew
DEBUGFS=/opt/homebrew/opt/e2fsprogs/sbin/debugfs
E2FSCK=/opt/homebrew/opt/e2fsprogs/sbin/e2fsck
QEMU_IMG=/opt/homebrew/bin/qemu-img

test -x "$DEBUGFS" || "$BREW" install e2fsprogs
test -x "$QEMU_IMG" || "$BREW" install qemu
```

Avoid `/Users/<user>/homebrew/bin/brew` for QEMU on Apple Silicon unless you deliberately want that prefix; it can build from source and take much longer.

Always inspect a booted/mutated APFS clone, not the installed source image, if you may run `e2fsck`:

```bash
tmpdir="$(mktemp -d /tmp/deepwork-vm-log.XXXXXX)"
install_dir="$(find "$HOME/Library/Application Support/deepwork/secure-vm" -maxdepth 4 -name manifest.json -print 2>/dev/null | head -n 1 | xargs dirname)"
rootfs_file="$(jq -r '.install.files[] | select(.role=="rootfs") | .fileName' "$install_dir/manifest.json")"
cp -c "$install_dir/$rootfs_file" "$tmpdir/rootfs.raw"

hdiutil attach -nomount -imagekey diskimage-class=CRawDiskImage "$tmpdir/rootfs.raw"
# Use the Linux Filesystem slice from hdiutil output, usually /dev/diskXs1.
"$DEBUGFS" -R 'cat /var/log/syslog' /dev/diskXs1 | rg 'deepworkd|bridge|systemd|NAMESPACE|226'
```

If `debugfs` reports a checksum or journal issue, run fsck only on the clone:

```bash
"$E2FSCK" -fy /dev/diskXs1
"$DEBUGFS" -R 'cat /var/log/syslog' /dev/diskXs1 | tail -n 200
hdiutil detach /dev/diskX
```

Log signatures:

- `Failed at step NAMESPACE` / `status=226/NAMESPACE`: systemd hardening or missing namespaced path; inspect `deepworkd.service`.
- `deepworkd.service unit entered`: `ExecStartPre` began; the unit is no longer failing before preflight.
- `deepworkd.service bridge port ready`: the named virtio port exists in the guest.
- `[deepworkd] ... "event":"bridge_open_ok"`: the daemon opened `/dev/virtio-ports/deepwork.bridge`; next inspect host/stdin JSONL handshake.

## Direct Bridge Reproduction

Use an APFS clone of the rootfs so the helper can mutate runtime state without touching the installed artifact:

```bash
tmpdir="$(mktemp -d /tmp/deepwork-vm-bridge.XXXXXX)"
install_dir="$(find "$HOME/Library/Application Support/deepwork/secure-vm" -maxdepth 4 -name manifest.json -print 2>/dev/null | head -n 1 | xargs dirname)"
rootfs_file="$(jq -r '.install.files[] | select(.role=="rootfs") | .fileName' "$install_dir/manifest.json")"
cp -c "$install_dir/$rootfs_file" "$tmpdir/rootfs.raw"

helper="out/resources/macos-secure-vm-helper/SecureVMBootSmokeHelper"
if [ ! -x "$helper" ]; then
  helper="/Applications/DeepWork.app/Contents/Resources/app.asar.unpacked/out/resources/macos-secure-vm-helper/SecureVMBootSmokeHelper"
fi

"$helper" \
  --deepworkd-bridge \
  --boot-loader=efi \
  --disk-image="$tmpdir/rootfs.raw" \
  --efi-variable-store="$tmpdir/efivars.fd" \
  --timeout-ms=180000
```

Run the helper in a TTY or interactive session. After `deepworkd.service preflight complete starting JSONL bridge`, send:

```jsonl
{"id":"hello-1","type":"hello","protocolVersion":1,"sessionId":"smoke-session","host":{"app":"DeepWork","platform":"darwin","bridge":"virtio-jsonl"}}
{"id":"ready-1","type":"ready","protocolVersion":1,"sessionId":"smoke-session","manifest":{"productRuntimeName":"deepworkd-compatible","serviceName":"deepworkd.service","imageId":"deep-work-ubuntu-jammy-deepworkd-macos-arm64","protocolVersion":1}}
{"id":"exec-1","type":"execute","protocolVersion":1,"sessionId":"smoke-session","command":"uname -a","cwd":"/","timeoutMs":10000}
```

`hello_ok`, `ready_ok`, and `exitCode:0` prove the guest bridge and command path. A helper timeout without stdin only proves that no protocol request was sent. Timeout at `guest-login` points back to service/image provisioning; timeout at `deepworkd-preflight-complete` with no JSONL after sending hello points to host/guest port routing or daemon read/write behavior.

If direct helper reproduction crashes immediately with
`NSFileHandleOperationException` / `fileDescriptor`: rerun it in a TTY. The
macOS Virtualization serial attachment path can fail when the helper is started
with noninteractive pipe stdin, which is a reproduction artifact rather than a
guest readiness signal.

## Output

Lead with a short diagnosis:

```text
Category: guest bridge readiness
Evidence: vm_session_ready appeared, bridge_spawn started, then vm_session_failure said Last observed stage: guest-login.
Likely next fix: inspect image provisioning for deepworkd.service User=ubuntu before host-side guard changes.
```

Avoid vague “VM is slow” conclusions. Tie every claim to a log line, manifest field, or command result.
