---
name: deepwork-windows-log-diagnosis
description: Diagnose local DeepWork Windows desktop logs, audit records, and Windows Hyper-V secure workspace execution metadata. Use when the user asks why Deep Work commands failed on Windows, whether the Windows secure workspace is unavailable/preparing/ready, why a Windows Hyper-V VM did not run, or asks to inspect app logs, audit logs, support bundle evidence, executionProfile, secureWorkspace, Windows VM prerequisites, or bundled Windows app readiness.
---

# DeepWork Windows Log Diagnosis

## Overview

Use this workflow to inspect the installed/development DeepWork Windows desktop app from the local machine. Keep the answer grounded in concrete log fields, not inferred UI labels.

## Workflow

1. Locate persistent app state under `~/.deepwork`, not Electron Chromium user data under `%APPDATA%\deepwork`.
   - Main log: `~/.deepwork/logs/app.jsonl`
   - Audit log: `~/.deepwork/audit.jsonl`
   - App settings: `~/.deepwork/settings.json`
   - Safe env key inventory: `~/.deepwork/.env`

2. Check recent Deep Work VM and runtime messages:

```powershell
Select-String -Path "$HOME\.deepwork\logs\app.jsonl" `
  -Pattern "DeepWorkVM|deep-work|Deep Work|Hyper-V|windows-hyperv|secure execution|unavailable|executionIsolation|executionProfile|secureWorkspace" |
  Select-Object -Last 120 |
  ForEach-Object { $_.Line }
```

3. Check recent execution audit records and summarize the fields that decide availability:

```powershell
Get-Content "$HOME\.deepwork\audit.jsonl" |
  ForEach-Object { try { $_ | ConvertFrom-Json } catch {} } |
  Where-Object { $_.type -eq "shell_command" } |
  Select-Object -Last 5 |
  ForEach-Object {
    [PSCustomObject]@{
      timestamp = $_.timestamp
      command = $_.command
      exitCode = $_.exitCode
      executionProfile = $_.metadata.executionProfile
      executionBackend = $_.metadata.executionBackend
      shellExecutionMode = $_.metadata.shellExecutionMode
      vmLifecycleState = $_.metadata.vmLifecycleState
      vmBridgeState = $_.metadata.vmBridgeState
      probeState = $_.metadata.deepWorkVmAvailabilityProbe.state
      executionAvailability = $_.metadata.deepWorkVmAvailabilityProbe.executionAvailability
      imagePreparation = $_.metadata.deepWorkVmAvailabilityProbe.imagePreparation
      jobState = $_.metadata.deepWorkExecutionJob.state
      jobError = $_.metadata.deepWorkExecutionJob.error
      unavailableReason = $_.metadata.unavailableReason
    }
  } | Format-List
```

4. Inspect settings only to understand global app configuration. Do not treat `executionIsolation.mode` as Deep Work state:

```powershell
Get-Content "$HOME\.deepwork\settings.json"
```

5. List env keys without exposing secret values:

```powershell
if (Test-Path "$HOME\.deepwork\.env") {
  Get-Content "$HOME\.deepwork\.env" |
    Where-Object { $_ -match '^\s*[^#=]+=' } |
    ForEach-Object { ($_ -split '=', 2)[0].Trim() } |
    Sort-Object
}
```

## Interpretation

- Source of truth for a Deep Work command is audit metadata on `shell_command`, especially `executionProfile`, `shellExecutionMode`, `deepWorkVmAvailabilityProbe.state`, `executionAvailability`, and `unavailableReason`.
- `executionIsolation.mode` is the legacy Deep Code host/docker shell setting. In a Deep Work thread it is not proof that the command used host shell, and it is not a fallback path.
- If `executionProfile` is `deep-work-secure` and `shellExecutionMode` is `unavailable`, the command was routed to Deep Work secure and failed closed.
- If `probeState` or `executionAvailability` is `unavailable`, report it as unavailable. Do not describe it as merely preparing unless the probe explicitly says `executionAvailability: preparing`.
- Missing `DEEP_WORK_SECURE_WINDOWS_VM_BACKEND`, `DEEP_WORK_SECURE_GUEST_NETWORK_MODE`, `DEEP_WORK_SECURE_WINDOWS_VM_HELPER_PATH`, `DEEP_WORK_SECURE_WINDOWS_VM_NAME`, `DEEP_WORK_SECURE_WINDOWS_VM_IMAGE_PATH`, or `DEEP_WORK_SECURE_VM_IMAGE_MANIFEST_PATH` means the installed Windows app cannot provide the Hyper-V secure workspace yet.

## Reporting

Answer with:

- Current verdict: ready, preparing, unavailable, or unknown.
- Evidence: 3-6 exact fields from the newest relevant audit row.
- Cause: the shortest actionable unavailable reason, grouped if several prerequisites are missing.
- Product implication: whether this is a deployment/prerequisite gap, runtime bug, or UI/copy bug.
- Caution: mention if app logs are older than audit logs or if no recent shell audit exists.
